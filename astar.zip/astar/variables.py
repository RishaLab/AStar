import re
import sys
import random

file = open('target.py','r').readlines()
file2 = open('target.py','r').read()

keys=['append','pop','print']

ids = re.findall(r"[a-zA-Z_]+[a-zA-Z0-9_]*",file2)

ids = set(ids).difference(keys)

print(ids)

id_lines = {}

final_id = {}

for each_line in file:
    line = each_line.strip()
    print(line)
    for each_id in ids:
        if line.find(each_id)!=-1:
            print(each_id + " Yes")
            if each_id in id_lines.keys():
                id_lines[each_id].append(line)
            else:
                id_lines[each_id] = [line] 

print(id_lines)

final_id = {}

for key in id_lines.keys():
    cur_list = id_lines[key]
    for line in cur_list:
        print('--------------'+line+'------------')
        if line.find('=')!=-1:
            lhs = line.split('=')[0].strip()
            rhs = line.split('=')[1].strip()
            if lhs.find(key)!=-1:
                print(key + ': assign')
                if key in final_id.keys():
                    final_id[key].append(['assign', line])
                else:
                    final_id[key] = [['assign',line]]
            else:
                for word in keys:
                    if line.find(word)!=-1:
                        print(key + ':'+word)
                        if key in final_id.keys():
                            final_id[key].append([word, line])
                        else:
                            final_id[key] = [[word,line]]
        else:
            for word in keys:
                if line.find(word)!=-1:
                    print(key + ':'+word)
                    if key in final_id.keys():
                        final_id[key].append([word, line])
                    else:
                        final_id[key] = [[word,line]]

# print(id_lines)

print(final_id)

ratio = 0.5

header = '''
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>

</head>

<!-- x z y -->
<script src="https://aframe.io/releases/1.0.3/aframe.min.js"></script>
<!-- include ar.js for A-Frame -->
<script src="https://jeromeetienne.github.io/AR.js/aframe/build/aframe-ar.js"></script>

<body>

    <div>

        <a-scene { display: block; width: 50%; }>

'''

footer = '''

            <a-marker-camera preset='custom' type='pattern' url='/static/arjs_marker.patt'></a-marker-camera>
        </a-scene>

    </div>
</body>

</html>
'''

def get_entity(pos):
    line = "        <a-box position=\'"+str(pos)+"\' height=0.30; width=0.30; depth=0.30; material=\'opacity: 1;\' color = \""+"blue"+"\"></a-box>\n"
    line2 = "        <a-box position=\'"+str(pos)+"\' height=0.001; width=0.325; depth=0.325; material=\'opacity: 1;\' color = \""+"white"+"\"></a-box>\n"
    line = line + line2
    # line = "        <a-box position=\'"+str(pos)+"\' height = 0.040; width = 0.040; depth = 0.040; material=\'opacity: 1;\' color = \""+"blue"+"\"></a-box>\n"
    # line = "        <a-cylinder rotation='-80 0 0' position=\'"+str(pos)+"\' animation=\"property: material.opacity; to: 1.0; dur: 3000; delay: "+str(delay)+";\" height = 0.20; radius = 0.14 material='opacity: 0;' color = \"orange\"></a-cylinder>"
    return line


def get_entity_red(pos):
    line = "        <a-box position=\'"+str(pos)+"\' height=0.15; width=0.40; depth=0.15; material=\'opacity: 1;\' color = \""+"red"+"\"></a-box>\n"
    line2 = "        <a-box position=\'"+str(pos)+"\' height=0.0015; width=0.425; depth=0.175; material=\'opacity: 1;\' color = \""+"white"+"\"></a-box>\n"
    line = line + line2
    # line = "        <a-box position=\'"+str(pos)+"\' height = 0.040; width = 0.040; depth = 0.040; material=\'opacity: 1;\' color = \""+"blue"+"\"></a-box>\n"
    # line = "        <a-cylinder rotation='-80 0 0' position=\'"+str(pos)+"\' animation=\"property: material.opacity; to: 1.0; dur: 3000; delay: "+str(delay)+";\" height = 0.20; radius = 0.14 material='opacity: 0;' color = \"orange\"></a-cylinder>"
    return line

def get_entity_yellow(pos):
    line = "        <a-box position=\'"+str(pos)+"\' height=0.15; width=0.40; depth=0.15; material=\'opacity: 1;\' color = \""+"brown"+"\"></a-box>\n"
    line2 = "        <a-box position=\'"+str(pos)+"\' height=0.001; width=0.45; depth=0.175; material=\'opacity: 1;\' color = \""+"yellow"+"\"></a-box>\n" 
    # line = "        <a-box position=\'"+str(pos)+"\' height = 0.040; width = 0.040; depth = 0.040; material=\'opacity: 1;\' color = \""+"blue"+"\"></a-box>\n"
    # line = "        <a-cylinder rotation='-80 0 0' position=\'"+str(pos)+"\' animation=\"property: material.opacity; to: 1.0; dur: 3000; delay: "+str(delay)+";\" height = 0.20; radius = 0.14 material='opacity: 0;' color = \"orange\"></a-cylinder>"
    line = line + line2
    return line

def get_line(start, end):
    line = "<a-entity line=\"start: "+str(start)+"; end: "+str(end)+"; color: white\"></a-entity>"
    return line

def get_text(text, pos, thick):
    line = "        <a-text rotation=\"-90 0 0\"  material=\'opacity: 1;\' width="+str(thick/2)+" position = \""+ str(pos) +"\" value=\""+ text +"\"></a-text>\n"
    return line


def get_pos(pos):
    pos_str = str(pos[0])+" "+str(pos[1])+" "+str(pos[2])
    return pos_str


init_pos = [0,0,0]


f = open('templates/index_test.html','w+')

f.write(header)

tot = 0

for key in final_id.keys():    
    x = len(final_id[key])
    tot = tot + x

lee = len(final_id.keys())
cur = -3

for key in final_id.keys():    
    x = len(final_id[key])
    lr = random.uniform(-1,1)
    pos = [cur+0.4 , lr, 0]
    text_pos = [cur+0.4 , lr+0.2, 0]
    f.write(get_entity(get_pos(pos)))
    f.write(get_text(str(key),get_pos(text_pos), 7))
    y = 0.65
    new_cur = cur
    for a in final_id[key]:
        br = random.uniform(-0.3,0.3)
        f.write(get_line(get_pos([new_cur, lr+br, y]), get_pos([cur+0.4 , lr, 0])))
        f.write(get_entity_red(get_pos([new_cur, lr+br, y])))
        f.write(get_text(str(a[0]),get_pos([new_cur-0.2, lr+br+0.2, y]), 5))
        f.write(get_entity_yellow(get_pos([new_cur, lr+br, y+0.3])))
        f.write(get_text(str(a[1]),get_pos([new_cur-0.2, lr+br+0.2, y+0.3]), 5))
        y = y + 0.65
        new_cur = (new_cur + 4/tot)
    cur = cur + (6/lee)

f.write(footer)
f.close()

# def add_position(key, lev, prev):
#     print(key)
#     print(lev)
#     pos = [0.0,0.0,0.0]
#     pos[2] = lev/2.0
#     pos[0] = prev
#     positions.append([key, pos, lev])
#     lev = lev + 1
#     queue = []
#     try:
#         for j in flow[key]:
#             queue.append([j,lev,prev])
#             prev = prev + 0.8
#     except:
#         pass

#     for j in queue:
#         add_position(j[0], j[1], j[2])


# parent = [0,0,1,1,2,2,1]

# def add_nodes(postions, delay):
    
#     prev_pos = positions[0][1]
#     prev_delay = 0
#     for kk,i in enumerate(positions[1:]):
#         print(i[1])
#         delay = 4000 * i[2]
#         delay_line = delay - 1000
#         pos_str = get_pos(i[1])
#         text_pos = [i[1][0], i[1][1]+0.15, i[1][2]]
#         text_str = get_pos(text_pos)
#         print(pos_str)
#         f.write(get_entity(pos_str, delay) +'\n'+ get_text(i[0], text_str, delay) + '\n'+ get_line(get_pos(positions[parent[kk]][1]), pos_str, delay_line) + '\n\n')
#         prev_pos = i[1]
#         prev_delay = delay
        
        
# add_position("main()", 0, 0)
# print(positions)

# f.write(header)

# k = positions[0]
# delay = 4000 * k[2]
# pos_str = get_pos(k[1])
# text_pos = [k[1][0], k[1][1]+0.15, k[1][2]]
# text_str = get_pos(text_pos)



# print(pos_str)
# f.write('\n\n'+get_entity(pos_str, delay) + '\n' + get_text(k[0], text_str, delay) + '\n\n')
# add_nodes(positions, 0)
# f.write(footer)
# f.close()
# #for i in protocols:
# #     pos = [0.0,0.0,0.0]
    
# #     choice = random.choice(['1','-1'])
# #         if choice == '1':
# #             pos[1] = random.random()
# #         else:
# #             pos[1] = -1 * random.random()
# #     print(choice)
