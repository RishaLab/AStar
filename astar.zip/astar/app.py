import sys
import random
import re
import sys
import os
import time

from flask import Flask, render_template, request

app = Flask(__name__)


@app.route('/')
def home():
    open('templates/index_test.html', 'w').close()
    time.sleep(1)
    return render_template('home.html')

@app.route('/generate', methods =['POST'])
def generate():
    if request.method =='POST':
        open('templates/index_test.html', 'w').close()
        time.sleep(1)
        code = request.form['nm'].split('\r\n')
        f = open('target.py', 'w')
        f.write(str(request.form['nm']))
        f.close()
        time.sleep(2)
        cmd = 'python test.py'
        os.system(cmd)
        time.sleep(2)
        f = open('target.py', 'w')
        f.write('')
        f.close()
        return render_template('index_test.html', result=code)

if __name__ == '__main__':
    app.run(debug=True)
