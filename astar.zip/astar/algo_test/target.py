stack = []

for i in range(10):
    if len(stack) > 1:
        stack.pop()
        print(stack)
    else:
        stack.append(1)
        b = stack.top()

b = stack.pop()

